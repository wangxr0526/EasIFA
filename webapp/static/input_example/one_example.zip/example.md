Endohydrolysis of (1->4)-beta-D-glucosidic linkages in cellulose, lichenin and cereal beta-D-glucans.

`P26222-rxn.txt` stores the enzyme-catalyzed reactions, and `P26222.pdb` contains the enzyme's PDB structure. Please upload the data as required to perform predictions for this case.